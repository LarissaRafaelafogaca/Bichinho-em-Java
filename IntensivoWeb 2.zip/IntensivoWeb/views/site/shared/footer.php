
<footer>
    <div class="container">

        Curso Intensivo - Todos os direitos reservados

    </div>
</footer>